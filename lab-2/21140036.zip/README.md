### this sql file was created using the following command

```
docker exec -t comp337-db-1 pg_dump -U admin university > university.sql
```

### to rebuild the database run the following command

```
cat university.sql | docker exec -i <container-name> psql -U admin -d <database-name>
```
