--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: advisor; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.advisor (
    s_id integer NOT NULL,
    i_id integer
);


ALTER TABLE public.advisor OWNER TO admin;

--
-- Name: classroom; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.classroom (
    building character varying(255) NOT NULL,
    room_number smallint NOT NULL,
    capacity integer
);


ALTER TABLE public.classroom OWNER TO admin;

--
-- Name: course; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.course (
    course_id character varying(7) NOT NULL,
    title character varying(255) NOT NULL,
    dept_name character varying(255),
    credits smallint NOT NULL
);


ALTER TABLE public.course OWNER TO admin;

--
-- Name: department; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.department (
    dept_name character varying(255) NOT NULL,
    building character varying(255) NOT NULL,
    budget integer
);


ALTER TABLE public.department OWNER TO admin;

--
-- Name: instructor; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.instructor (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    dept_name character varying(255) NOT NULL,
    salary integer
);


ALTER TABLE public.instructor OWNER TO admin;

--
-- Name: instructor_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.instructor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.instructor_id_seq OWNER TO admin;

--
-- Name: instructor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.instructor_id_seq OWNED BY public.instructor.id;


--
-- Name: prereq; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.prereq (
    course_id character varying(7),
    prereq_id character varying(7)
);


ALTER TABLE public.prereq OWNER TO admin;

--
-- Name: section; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.section (
    course_id character varying(7) NOT NULL,
    sec_id smallint,
    semester character varying(255),
    year smallint,
    building character varying(255),
    room_number smallint,
    time_slot_id integer
);


ALTER TABLE public.section OWNER TO admin;

--
-- Name: student; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.student (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    dept_name character varying(255),
    tot_cred smallint
);


ALTER TABLE public.student OWNER TO admin;

--
-- Name: student_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.student_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_id_seq OWNER TO admin;

--
-- Name: student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.student_id_seq OWNED BY public.student.id;


--
-- Name: takes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.takes (
    id integer NOT NULL,
    course_id character varying(7),
    sec_id smallint,
    semester character varying(255),
    year smallint,
    grade smallint
);


ALTER TABLE public.takes OWNER TO admin;

--
-- Name: takes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.takes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.takes_id_seq OWNER TO admin;

--
-- Name: takes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.takes_id_seq OWNED BY public.takes.id;


--
-- Name: teaches; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.teaches (
    id integer NOT NULL,
    course_id character varying(7),
    sec_id smallint,
    semester character varying(255),
    year smallint
);


ALTER TABLE public.teaches OWNER TO admin;

--
-- Name: teaches_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.teaches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teaches_id_seq OWNER TO admin;

--
-- Name: teaches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.teaches_id_seq OWNED BY public.teaches.id;


--
-- Name: time_slot; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.time_slot (
    time_slot_id integer NOT NULL,
    day character varying(255) NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL
);


ALTER TABLE public.time_slot OWNER TO admin;

--
-- Name: time_slot_time_slot_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.time_slot_time_slot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_slot_time_slot_id_seq OWNER TO admin;

--
-- Name: time_slot_time_slot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.time_slot_time_slot_id_seq OWNED BY public.time_slot.time_slot_id;


--
-- Name: instructor id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.instructor ALTER COLUMN id SET DEFAULT nextval('public.instructor_id_seq'::regclass);


--
-- Name: student id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.student ALTER COLUMN id SET DEFAULT nextval('public.student_id_seq'::regclass);


--
-- Name: takes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.takes ALTER COLUMN id SET DEFAULT nextval('public.takes_id_seq'::regclass);


--
-- Name: teaches id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.teaches ALTER COLUMN id SET DEFAULT nextval('public.teaches_id_seq'::regclass);


--
-- Name: time_slot time_slot_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.time_slot ALTER COLUMN time_slot_id SET DEFAULT nextval('public.time_slot_time_slot_id_seq'::regclass);


--
-- Data for Name: advisor; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.advisor (s_id, i_id) FROM stdin;
1	2
2	1
3	2
4	1
5	3
6	2
7	3
8	2
9	2
10	3
11	3
12	2
13	1
14	3
15	3
16	3
17	1
18	1
19	1
20	2
21	3
22	1
23	2
24	2
25	1
26	4
27	4
28	6
29	5
30	6
31	6
32	5
33	5
34	4
35	4
36	4
37	6
38	6
39	6
40	4
41	5
42	6
43	6
44	5
45	7
46	7
47	8
48	9
49	8
50	8
51	7
52	7
53	7
54	7
55	7
56	7
57	8
58	8
59	8
60	12
61	10
62	10
63	10
64	12
65	10
66	11
67	10
68	12
69	10
70	11
71	12
72	11
73	11
74	11
75	13
76	14
77	13
78	14
79	13
80	13
81	14
82	15
83	13
84	13
85	14
86	15
87	14
88	14
89	15
90	18
91	18
92	17
93	17
94	18
95	17
96	16
97	17
98	17
99	16
100	16
101	18
102	17
103	18
104	17
105	19
106	19
107	20
108	19
109	21
110	19
111	20
112	21
113	20
114	21
115	22
116	22
117	24
118	23
119	22
120	22
121	22
122	22
123	22
124	23
125	25
126	25
127	27
128	27
129	26
130	26
131	25
132	25
133	25
134	27
\.


--
-- Data for Name: classroom; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.classroom (building, room_number, capacity) FROM stdin;
CS	100	100
CS	101	30
CS	102	30
CS	103	30
CS	104	30
SOFT	100	100
SOFT	101	30
SOFT	102	30
SOFT	103	30
SOFT	104	30
COMP	100	100
COMP	101	30
COMP	102	30
COMP	103	30
COMP	104	30
ELEC	100	100
ELEC	101	30
ELEC	102	30
ELEC	103	30
ELEC	104	30
MECH	100	100
MECH	101	30
MECH	102	30
MECH	103	30
MECH	104	30
CIV	100	100
CIV	101	30
CIV	102	30
CIV	103	30
CIV	104	30
PHY	100	100
PHY	101	30
PHY	102	30
PHY	103	30
PHY	104	30
CHEM	100	100
CHEM	101	30
CHEM	102	30
CHEM	103	30
CHEM	104	30
BIO	100	100
BIO	101	30
BIO	102	30
BIO	103	30
BIO	104	30
\.


--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.course (course_id, title, dept_name, credits) FROM stdin;
cs101	Introduction to Programming	computer science	4
cs102	Data Structures	computer science	4
cs201	Algorithms	computer science	3
cs202	Computer Organization	computer science	3
cs301	Operating Systems	computer science	3
cs302	Database Systems	computer science	3
cs401	Artificial Intelligence	computer science	4
cs402	Machine Learning	computer science	4
seng101	Introduction to Software Engineering	software engineering	4
seng102	Software Requirements	software engineering	4
seng201	Software Design	software engineering	3
seng202	Software Testing	software engineering	3
seng301	Agile Software Development	software engineering	3
seng302	Software Project Management	software engineering	3
seng401	Software Architecture	software engineering	4
seng402	Advanced Software Engineering	software engineering	4
comp101	Introduction to Computer Engineering	computer engineering	4
comp102	Digital Logic Design	computer engineering	4
comp201	Microprocessors	computer engineering	3
comp202	Embedded Systems	computer engineering	3
comp301	Computer Networks	computer engineering	3
comp302	VLSI Design	computer engineering	3
comp401	Computer Vision	computer engineering	4
comp402	High Performance Computing	computer engineering	4
elec101	Circuit Analysis	electrical engineering	4
elec102	Electromagnetics	electrical engineering	4
elec201	Analog Electronics	electrical engineering	3
elec202	Signals and Systems	electrical engineering	3
elec301	Digital Signal Processing	electrical engineering	3
elec302	Power Electronics	electrical engineering	3
elec401	Control Systems	electrical engineering	4
elec402	Electrical Machines	electrical engineering	4
mech101	Engineering Mechanics	mechanical engineering	4
mech102	Thermodynamics	mechanical engineering	4
mech201	Fluid Mechanics	mechanical engineering	3
mech202	Heat Transfer	mechanical engineering	3
mech301	Mechanical Vibrations	mechanical engineering	3
mech302	Dynamics of Machinery	mechanical engineering	3
mech401	Robotics	mechanical engineering	4
mech402	Advanced Thermodynamics	mechanical engineering	4
civ101	Introduction to Civil Engineering	civil engineering	4
civ102	Structural Analysis	civil engineering	4
civ201	Geotechnical Engineering	civil engineering	3
civ202	Construction Materials	civil engineering	3
civ301	Hydraulics	civil engineering	3
civ302	Transportation Engineering	civil engineering	3
civ401	Structural Design	civil engineering	4
civ402	Environmental Engineering	civil engineering	4
phy101	Introduction to Physics	physics	4
phy102	Mechanics	physics	4
phy201	Electromagnetism	physics	3
phy202	Quantum Mechanics	physics	3
phy301	Thermal Physics	physics	3
phy302	Solid State Physics	physics	3
phy401	Nuclear Physics	physics	4
phy402	Particle Physics	physics	4
chem101	Introduction to Chemistry	chemistry	4
chem102	Organic Chemistry	chemistry	4
chem201	Inorganic Chemistry	chemistry	3
chem202	Physical Chemistry	chemistry	3
chem301	Analytical Chemistry	chemistry	3
chem302	Biochemistry	chemistry	3
chem401	Industrial Chemistry	chemistry	4
chem402	Environmental Chemistry	chemistry	4
bio101	Introduction to Biology	biology	4
bio102	Cell Biology	biology	4
bio201	Genetics	biology	3
bio202	Microbiology	biology	3
bio301	Ecology	biology	3
bio302	Molecular Biology	biology	3
bio401	Evolutionary Biology	biology	4
bio402	Biotechnology	biology	4
\.


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.department (dept_name, building, budget) FROM stdin;
computer science	CS	50000
software engineering	SOFT	60000
computer engineering	COMP	80000
electrical engineering	ELEC	90000
mechanical engineering	MECH	70000
civil engineering	CIV	75000
physics	PHY	68000
chemistry	CHEM	85000
biology	BIO	65000
\.


--
-- Data for Name: instructor; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.instructor (id, name, dept_name, salary) FROM stdin;
1	ferhun yorgancioglu	computer engineering	70000
2	cem kalyoncu	computer engineering	65000
3	zafer erenel	computer engineering	80000
4	vesile evrim	software engineering	75000
5	abdelrahman mostafa	software engineering	48000
6	levent akinci	software engineering	55000
7	ahmet kaya	computer science	73000
8	ayse yilmaz	computer science	60000
9	mehmet demir	computer science	67000
10	elif akar	electrical engineering	71000
11	burak tan	electrical engineering	76000
12	selin onat	electrical engineering	82000
13	serkan polat	mechanical engineering	69000
14	nurcan kaya	mechanical engineering	72000
15	erol gunes	mechanical engineering	75000
16	mustafa tezcan	civil engineering	77000
17	zeynep altan	civil engineering	78000
18	cemre duru	civil engineering	73000
19	hakan erol	physics	65000
20	melike ozturk	physics	67000
21	kerem yilmaz	physics	72000
22	fatma arslan	chemistry	81000
23	ozlem dag	chemistry	78000
24	ismet arikan	chemistry	82000
25	yasemin uzay	biology	66000
26	erdem taner	biology	64000
27	gulay tekin	biology	63000
\.


--
-- Data for Name: prereq; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.prereq (course_id, prereq_id) FROM stdin;
cs102	cs101
cs201	cs102
cs202	cs201
cs301	cs202
cs302	cs201
cs401	cs301
cs402	cs401
seng102	seng101
seng201	seng102
seng202	seng201
seng301	seng202
seng302	seng301
seng401	seng302
seng402	seng401
comp102	comp101
comp201	comp102
comp202	comp201
comp301	comp202
comp302	comp201
comp401	comp301
comp402	comp401
elec102	elec101
elec201	elec102
elec202	elec201
elec301	elec202
elec302	elec301
elec401	elec202
elec402	elec401
mech102	mech101
mech201	mech102
mech202	mech201
mech301	mech202
mech302	mech301
mech401	mech302
mech402	mech401
civ102	civ101
civ201	civ102
civ202	civ201
civ301	civ202
civ302	civ201
civ401	civ301
civ402	civ401
phy102	phy101
phy201	phy102
phy202	phy201
phy301	phy202
phy302	phy301
phy401	phy301
phy402	phy401
chem102	chem101
chem201	chem102
chem202	chem201
chem301	chem202
chem302	chem301
chem401	chem301
chem402	chem401
bio102	bio101
bio201	bio102
bio202	bio201
bio301	bio202
bio302	bio201
bio401	bio301
bio402	bio401
\.


--
-- Data for Name: section; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.section (course_id, sec_id, semester, year, building, room_number, time_slot_id) FROM stdin;
cs101	1	Fall	2024	CS	100	1
cs101	2	Fall	2024	CS	100	2
cs102	1	Spring	2025	CS	101	3
cs102	2	Spring	2025	CS	101	4
cs201	1	Fall	2024	CS	102	5
cs201	2	Fall	2024	CS	102	6
cs202	1	Spring	2025	CS	103	7
cs202	2	Spring	2025	CS	103	8
cs301	1	Fall	2024	CS	104	9
cs301	2	Fall	2024	CS	104	10
cs302	1	Spring	2025	CS	100	11
cs302	2	Spring	2025	CS	100	12
cs401	1	Fall	2024	CS	101	13
cs401	2	Fall	2024	CS	101	14
cs402	1	Spring	2025	CS	102	15
cs402	2	Spring	2025	CS	102	16
seng101	1	Fall	2024	SOFT	100	17
seng101	2	Fall	2024	SOFT	100	18
seng102	1	Spring	2025	SOFT	101	19
seng102	2	Spring	2025	SOFT	101	20
seng201	1	Fall	2024	SOFT	102	1
seng201	2	Fall	2024	SOFT	102	2
seng202	1	Spring	2025	SOFT	103	3
seng202	2	Spring	2025	SOFT	103	4
seng301	1	Fall	2024	SOFT	104	5
seng301	2	Fall	2024	SOFT	104	6
seng302	1	Spring	2025	SOFT	100	7
seng302	2	Spring	2025	SOFT	100	8
seng401	1	Fall	2024	SOFT	101	9
seng401	2	Fall	2024	SOFT	101	10
seng402	1	Spring	2025	SOFT	102	11
seng402	2	Spring	2025	SOFT	102	12
comp101	1	Fall	2024	COMP	100	13
comp101	2	Fall	2024	COMP	100	14
comp102	1	Spring	2025	COMP	101	15
comp102	2	Spring	2025	COMP	101	16
comp201	1	Fall	2024	COMP	102	17
comp201	2	Fall	2024	COMP	102	18
comp202	1	Spring	2025	COMP	103	19
comp202	2	Spring	2025	COMP	103	20
comp301	1	Fall	2024	COMP	104	1
comp301	2	Fall	2024	COMP	104	2
comp302	1	Spring	2025	COMP	100	3
comp302	2	Spring	2025	COMP	100	4
comp401	1	Fall	2024	COMP	101	5
comp401	2	Fall	2024	COMP	101	6
comp402	1	Spring	2025	COMP	102	7
comp402	2	Spring	2025	COMP	102	8
elec101	1	Fall	2024	ELEC	100	9
elec101	2	Fall	2024	ELEC	100	10
elec102	1	Spring	2025	ELEC	101	11
elec102	2	Spring	2025	ELEC	101	12
elec201	1	Fall	2024	ELEC	102	13
elec201	2	Fall	2024	ELEC	102	14
elec202	1	Spring	2025	ELEC	103	15
elec202	2	Spring	2025	ELEC	103	16
elec301	1	Fall	2024	ELEC	104	17
elec301	2	Fall	2024	ELEC	104	18
elec302	1	Spring	2025	ELEC	100	19
elec302	2	Spring	2025	ELEC	100	20
elec401	1	Fall	2024	ELEC	101	1
elec401	2	Fall	2024	ELEC	101	2
elec402	1	Spring	2025	ELEC	102	3
elec402	2	Spring	2025	ELEC	102	4
mech101	1	Fall	2024	MECH	100	5
mech101	2	Fall	2024	MECH	100	6
mech102	1	Spring	2025	MECH	101	7
mech102	2	Spring	2025	MECH	101	8
mech201	1	Fall	2024	MECH	102	9
mech201	2	Fall	2024	MECH	102	10
mech202	1	Spring	2025	MECH	103	11
mech202	2	Spring	2025	MECH	103	12
mech301	1	Fall	2024	MECH	104	13
mech301	2	Fall	2024	MECH	104	14
mech302	1	Spring	2025	MECH	100	15
mech302	2	Spring	2025	MECH	100	16
mech401	1	Fall	2024	MECH	101	17
mech401	2	Fall	2024	MECH	101	18
mech402	1	Spring	2025	MECH	102	19
mech402	2	Spring	2025	MECH	102	20
civ101	1	Fall	2024	CIV	100	1
civ101	2	Fall	2024	CIV	100	2
civ102	1	Spring	2025	CIV	101	3
civ102	2	Spring	2025	CIV	101	4
civ201	1	Fall	2024	CIV	102	5
civ201	2	Fall	2024	CIV	102	6
civ202	1	Spring	2025	CIV	103	7
civ202	2	Spring	2025	CIV	103	8
civ301	1	Fall	2024	CIV	104	9
civ301	2	Fall	2024	CIV	104	10
civ302	1	Spring	2025	CIV	100	11
civ302	2	Spring	2025	CIV	100	12
civ401	1	Fall	2024	CIV	101	13
civ401	2	Fall	2024	CIV	101	14
civ402	1	Spring	2025	CIV	102	15
civ402	2	Spring	2025	CIV	102	16
phy101	1	Fall	2024	PHY	100	17
phy101	2	Fall	2024	PHY	100	18
phy102	1	Spring	2025	PHY	101	19
phy102	2	Spring	2025	PHY	101	20
phy201	1	Fall	2024	PHY	102	1
phy201	2	Fall	2024	PHY	102	2
phy202	1	Spring	2025	PHY	103	3
phy202	2	Spring	2025	PHY	103	4
phy301	1	Fall	2024	PHY	104	5
phy301	2	Fall	2024	PHY	104	6
phy302	1	Spring	2025	PHY	100	7
phy302	2	Spring	2025	PHY	100	8
phy401	1	Fall	2024	PHY	101	9
phy401	2	Fall	2024	PHY	101	10
phy402	1	Spring	2025	PHY	102	11
phy402	2	Spring	2025	PHY	102	12
chem101	1	Fall	2024	CHEM	100	13
chem101	2	Fall	2024	CHEM	100	14
chem102	1	Spring	2025	CHEM	101	15
chem102	2	Spring	2025	CHEM	101	16
chem201	1	Fall	2024	CHEM	102	17
chem201	2	Fall	2024	CHEM	102	18
chem202	1	Spring	2025	CHEM	103	19
chem202	2	Spring	2025	CHEM	103	20
chem301	1	Fall	2024	CHEM	104	1
chem301	2	Fall	2024	CHEM	104	2
chem302	1	Spring	2025	CHEM	100	3
chem302	2	Spring	2025	CHEM	100	4
chem401	1	Fall	2024	CHEM	101	5
chem401	2	Fall	2024	CHEM	101	6
chem402	1	Spring	2025	CHEM	102	7
chem402	2	Spring	2025	CHEM	102	8
bio101	1	Fall	2024	BIO	100	9
bio101	2	Fall	2024	BIO	100	10
bio102	1	Spring	2025	BIO	101	11
bio102	2	Spring	2025	BIO	101	12
bio201	1	Fall	2024	BIO	102	13
bio201	2	Fall	2024	BIO	102	14
bio202	1	Spring	2025	BIO	103	15
bio202	2	Spring	2025	BIO	103	16
bio301	1	Fall	2024	BIO	104	17
bio301	2	Fall	2024	BIO	104	18
bio302	1	Spring	2025	BIO	100	19
bio302	2	Spring	2025	BIO	100	20
bio401	1	Fall	2024	BIO	101	1
bio401	2	Fall	2024	BIO	101	2
bio402	1	Spring	2025	BIO	102	3
bio402	2	Spring	2025	BIO	102	4
\.


--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.student (id, name, dept_name, tot_cred) FROM stdin;
1	ahmet can	computer science	45
2	ayse yilmaz	computer science	55
3	mehmet kaya	computer science	30
4	fatma demir	computer science	40
5	burak tan	computer science	60
6	selin onat	computer science	25
7	canan yilmaz	computer science	50
8	enes kaya	computer science	35
9	cem yilmaz	computer science	42
10	gizem kara	computer science	48
11	elif yilmaz	computer science	52
12	veli kaya	computer science	57
13	gokhan aydin	computer science	36
14	selin tan	computer science	47
15	nur karaca	computer science	33
16	meltem demir	computer science	29
17	hasan aydin	computer science	45
18	kemal onur	computer science	41
19	ziya gunes	computer science	56
20	arda yilmaz	computer science	34
21	furkan tan	computer science	40
22	mert yildiz	computer science	51
23	ayse gunes	computer science	60
24	yusuf kara	computer science	28
25	seda kaya	computer science	49
26	emre uzun	software engineering	39
27	berna yilmaz	software engineering	57
28	koray tan	software engineering	44
29	yigit kaya	software engineering	32
30	ece yilmaz	software engineering	53
31	irem kara	software engineering	61
32	kadir demir	software engineering	26
33	dilara tan	software engineering	50
34	oguz yildiz	software engineering	36
35	arda tan	software engineering	40
36	tugce kaya	software engineering	46
37	cansu yilmaz	software engineering	55
38	mert tan	software engineering	59
39	deniz kara	software engineering	60
40	bora demir	software engineering	48
41	gokce onat	software engineering	33
42	zeynep kaya	software engineering	38
43	ugur tan	software engineering	31
44	serra tan	software engineering	37
45	furkan kaya	computer engineering	54
46	kaan tan	computer engineering	30
47	melis yilmaz	computer engineering	51
48	emre kara	computer engineering	29
49	gokhan tan	computer engineering	50
50	aylin yilmaz	computer engineering	58
51	nuri kaya	computer engineering	40
52	ezgi yilmaz	computer engineering	35
53	kemal tan	computer engineering	43
54	serap tan	computer engineering	60
55	sinan yilmaz	computer engineering	56
56	elif demir	computer engineering	27
57	okan tan	computer engineering	53
58	sinem kaya	computer engineering	39
59	umit yilmaz	computer engineering	52
60	yigit gunes	electrical engineering	47
61	elif kaya	electrical engineering	42
62	emir tan	electrical engineering	38
63	ozlem kara	electrical engineering	55
64	sahin yilmaz	electrical engineering	50
65	emel tan	electrical engineering	62
66	omer kaya	electrical engineering	30
67	gamze demir	electrical engineering	58
68	beyza tan	electrical engineering	45
69	mustafa yilmaz	electrical engineering	41
70	tamer kaya	electrical engineering	34
71	fatih tan	electrical engineering	39
72	kenan yilmaz	electrical engineering	51
73	burcu kara	electrical engineering	36
74	eren tan	electrical engineering	48
75	erdem kaya	mechanical engineering	60
76	hasan tan	mechanical engineering	30
77	meltem yilmaz	mechanical engineering	52
78	yasar kara	mechanical engineering	29
79	mert tan	mechanical engineering	47
80	didem yilmaz	mechanical engineering	54
81	cihan kaya	mechanical engineering	31
82	merve demir	mechanical engineering	42
83	enes tan	mechanical engineering	38
84	kerem yilmaz	mechanical engineering	46
85	duygu kara	mechanical engineering	59
86	sefa tan	mechanical engineering	35
87	hande yilmaz	mechanical engineering	56
88	berkay kaya	mechanical engineering	33
89	taner tan	mechanical engineering	40
90	didem yilmaz	civil engineering	43
91	kemal kaya	civil engineering	30
92	aylin tan	civil engineering	57
93	elif yilmaz	civil engineering	34
94	serkan kara	civil engineering	55
95	zeynep yilmaz	civil engineering	60
96	volkan kaya	civil engineering	45
97	sezgin tan	civil engineering	49
98	gulsah yilmaz	civil engineering	32
99	serdar tan	civil engineering	52
100	buket kara	civil engineering	46
101	onur tan	civil engineering	40
102	fatih yilmaz	civil engineering	48
103	funda kaya	civil engineering	33
104	nurdan yilmaz	civil engineering	36
105	cagri tan	physics	42
106	bahar yilmaz	physics	39
107	ilker kaya	physics	51
108	onur tan	physics	34
109	burak yilmaz	physics	30
110	selin kaya	physics	47
111	ozan yilmaz	physics	60
112	pelin tan	physics	58
113	ozlem kaya	physics	37
114	nazan yilmaz	physics	44
115	necla tan	chemistry	55
116	gokce yilmaz	chemistry	32
117	burak kaya	chemistry	49
118	ipek yilmaz	chemistry	39
119	berke tan	chemistry	46
120	aleyna kaya	chemistry	41
121	yagmur yilmaz	chemistry	36
122	okan tan	chemistry	50
123	tuce kaya	chemistry	59
124	nazim yilmaz	chemistry	53
125	cansu tan	biology	43
126	cenk yilmaz	biology	34
127	gul yilmaz	biology	37
128	salih kaya	biology	42
129	aykut tan	biology	60
130	melike yilmaz	biology	28
131	meltem kaya	biology	56
132	dicle tan	biology	35
133	baris yilmaz	biology	30
134	seren kaya	biology	50
\.


--
-- Data for Name: takes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.takes (id, course_id, sec_id, semester, year, grade) FROM stdin;
1	cs301	1	Fall	2024	\N
1	cs301	2	Fall	2024	\N
1	cs302	1	Spring	2025	\N
1	cs302	2	Spring	2025	\N
1	seng301	1	Fall	2024	\N
1	seng301	2	Fall	2024	\N
1	seng302	1	Spring	2025	\N
1	seng302	2	Spring	2025	\N
2	cs101	1	Fall	2024	\N
2	cs101	2	Fall	2024	\N
2	cs102	1	Spring	2025	\N
2	cs102	2	Spring	2025	\N
2	seng101	1	Fall	2024	\N
2	seng101	2	Fall	2024	\N
2	seng102	1	Spring	2025	\N
2	seng102	2	Spring	2025	\N
3	cs301	1	Fall	2024	\N
3	cs301	2	Fall	2024	\N
3	cs302	1	Spring	2025	\N
3	cs302	2	Spring	2025	\N
3	seng301	1	Fall	2024	\N
3	seng301	2	Fall	2024	\N
3	seng302	1	Spring	2025	\N
3	seng302	2	Spring	2025	\N
4	cs101	1	Fall	2024	\N
4	cs101	2	Fall	2024	\N
4	cs102	1	Spring	2025	\N
4	cs102	2	Spring	2025	\N
4	seng101	1	Fall	2024	\N
4	seng101	2	Fall	2024	\N
4	seng102	1	Spring	2025	\N
4	seng102	2	Spring	2025	\N
5	cs101	1	Fall	2024	\N
5	cs101	2	Fall	2024	\N
5	cs102	1	Spring	2025	\N
5	cs102	2	Spring	2025	\N
5	seng101	1	Fall	2024	\N
5	seng101	2	Fall	2024	\N
5	seng102	1	Spring	2025	\N
5	seng102	2	Spring	2025	\N
6	cs301	1	Fall	2024	\N
6	cs301	2	Fall	2024	\N
6	cs302	1	Spring	2025	\N
6	cs302	2	Spring	2025	\N
6	seng301	1	Fall	2024	\N
6	seng301	2	Fall	2024	\N
6	seng302	1	Spring	2025	\N
6	seng302	2	Spring	2025	\N
7	cs401	1	Fall	2024	\N
7	cs401	2	Fall	2024	\N
7	cs402	1	Spring	2025	\N
7	cs402	2	Spring	2025	\N
7	seng401	1	Fall	2024	\N
7	seng401	2	Fall	2024	\N
7	seng402	1	Spring	2025	\N
7	seng402	2	Spring	2025	\N
8	cs201	1	Fall	2024	\N
8	cs201	2	Fall	2024	\N
8	cs202	1	Spring	2025	\N
8	cs202	2	Spring	2025	\N
8	seng201	1	Fall	2024	\N
8	seng201	2	Fall	2024	\N
8	seng202	1	Spring	2025	\N
8	seng202	2	Spring	2025	\N
9	cs201	1	Fall	2024	\N
9	cs201	2	Fall	2024	\N
9	cs202	1	Spring	2025	\N
9	cs202	2	Spring	2025	\N
9	seng201	1	Fall	2024	\N
9	seng201	2	Fall	2024	\N
9	seng202	1	Spring	2025	\N
9	seng202	2	Spring	2025	\N
10	cs101	1	Fall	2024	\N
10	cs101	2	Fall	2024	\N
10	cs102	1	Spring	2025	\N
10	cs102	2	Spring	2025	\N
10	seng101	1	Fall	2024	\N
10	seng101	2	Fall	2024	\N
10	seng102	1	Spring	2025	\N
10	seng102	2	Spring	2025	\N
11	cs301	1	Fall	2024	\N
11	cs301	2	Fall	2024	\N
11	cs302	1	Spring	2025	\N
11	cs302	2	Spring	2025	\N
11	seng301	1	Fall	2024	\N
11	seng301	2	Fall	2024	\N
11	seng302	1	Spring	2025	\N
11	seng302	2	Spring	2025	\N
12	cs101	1	Fall	2024	\N
12	cs101	2	Fall	2024	\N
12	cs102	1	Spring	2025	\N
12	cs102	2	Spring	2025	\N
12	seng101	1	Fall	2024	\N
12	seng101	2	Fall	2024	\N
12	seng102	1	Spring	2025	\N
12	seng102	2	Spring	2025	\N
13	cs301	1	Fall	2024	\N
13	cs301	2	Fall	2024	\N
13	cs302	1	Spring	2025	\N
13	cs302	2	Spring	2025	\N
13	seng301	1	Fall	2024	\N
13	seng301	2	Fall	2024	\N
13	seng302	1	Spring	2025	\N
13	seng302	2	Spring	2025	\N
14	cs201	1	Fall	2024	\N
14	cs201	2	Fall	2024	\N
14	cs202	1	Spring	2025	\N
14	cs202	2	Spring	2025	\N
14	seng201	1	Fall	2024	\N
14	seng201	2	Fall	2024	\N
14	seng202	1	Spring	2025	\N
14	seng202	2	Spring	2025	\N
15	cs301	1	Fall	2024	\N
15	cs301	2	Fall	2024	\N
15	cs302	1	Spring	2025	\N
15	cs302	2	Spring	2025	\N
15	seng301	1	Fall	2024	\N
15	seng301	2	Fall	2024	\N
15	seng302	1	Spring	2025	\N
15	seng302	2	Spring	2025	\N
16	cs301	1	Fall	2024	\N
16	cs301	2	Fall	2024	\N
16	cs302	1	Spring	2025	\N
16	cs302	2	Spring	2025	\N
16	seng301	1	Fall	2024	\N
16	seng301	2	Fall	2024	\N
16	seng302	1	Spring	2025	\N
16	seng302	2	Spring	2025	\N
17	cs401	1	Fall	2024	\N
17	cs401	2	Fall	2024	\N
17	cs402	1	Spring	2025	\N
17	cs402	2	Spring	2025	\N
17	seng401	1	Fall	2024	\N
17	seng401	2	Fall	2024	\N
17	seng402	1	Spring	2025	\N
17	seng402	2	Spring	2025	\N
18	cs401	1	Fall	2024	\N
18	cs401	2	Fall	2024	\N
18	cs402	1	Spring	2025	\N
18	cs402	2	Spring	2025	\N
18	seng401	1	Fall	2024	\N
18	seng401	2	Fall	2024	\N
18	seng402	1	Spring	2025	\N
18	seng402	2	Spring	2025	\N
19	cs101	1	Fall	2024	\N
19	cs101	2	Fall	2024	\N
19	cs102	1	Spring	2025	\N
19	cs102	2	Spring	2025	\N
19	seng101	1	Fall	2024	\N
19	seng101	2	Fall	2024	\N
19	seng102	1	Spring	2025	\N
19	seng102	2	Spring	2025	\N
20	cs401	1	Fall	2024	\N
20	cs401	2	Fall	2024	\N
20	cs402	1	Spring	2025	\N
20	cs402	2	Spring	2025	\N
20	seng401	1	Fall	2024	\N
20	seng401	2	Fall	2024	\N
20	seng402	1	Spring	2025	\N
20	seng402	2	Spring	2025	\N
21	cs401	1	Fall	2024	\N
21	cs401	2	Fall	2024	\N
21	cs402	1	Spring	2025	\N
21	cs402	2	Spring	2025	\N
21	seng401	1	Fall	2024	\N
21	seng401	2	Fall	2024	\N
21	seng402	1	Spring	2025	\N
21	seng402	2	Spring	2025	\N
22	cs401	1	Fall	2024	\N
22	cs401	2	Fall	2024	\N
22	cs402	1	Spring	2025	\N
22	cs402	2	Spring	2025	\N
22	seng401	1	Fall	2024	\N
22	seng401	2	Fall	2024	\N
22	seng402	1	Spring	2025	\N
22	seng402	2	Spring	2025	\N
23	cs401	1	Fall	2024	\N
23	cs401	2	Fall	2024	\N
23	cs402	1	Spring	2025	\N
23	cs402	2	Spring	2025	\N
23	seng401	1	Fall	2024	\N
23	seng401	2	Fall	2024	\N
23	seng402	1	Spring	2025	\N
23	seng402	2	Spring	2025	\N
24	cs401	1	Fall	2024	\N
24	cs401	2	Fall	2024	\N
24	cs402	1	Spring	2025	\N
24	cs402	2	Spring	2025	\N
24	seng401	1	Fall	2024	\N
24	seng401	2	Fall	2024	\N
24	seng402	1	Spring	2025	\N
24	seng402	2	Spring	2025	\N
25	cs201	1	Fall	2024	\N
25	cs201	2	Fall	2024	\N
25	cs202	1	Spring	2025	\N
25	cs202	2	Spring	2025	\N
25	seng201	1	Fall	2024	\N
25	seng201	2	Fall	2024	\N
25	seng202	1	Spring	2025	\N
25	seng202	2	Spring	2025	\N
26	cs301	1	Fall	2024	\N
26	cs301	2	Fall	2024	\N
26	cs302	1	Spring	2025	\N
26	cs302	2	Spring	2025	\N
26	seng301	1	Fall	2024	\N
26	seng301	2	Fall	2024	\N
26	seng302	1	Spring	2025	\N
26	seng302	2	Spring	2025	\N
27	cs401	1	Fall	2024	\N
27	cs401	2	Fall	2024	\N
27	cs402	1	Spring	2025	\N
27	cs402	2	Spring	2025	\N
27	seng401	1	Fall	2024	\N
27	seng401	2	Fall	2024	\N
27	seng402	1	Spring	2025	\N
27	seng402	2	Spring	2025	\N
28	cs401	1	Fall	2024	\N
28	cs401	2	Fall	2024	\N
28	cs402	1	Spring	2025	\N
28	cs402	2	Spring	2025	\N
28	seng401	1	Fall	2024	\N
28	seng401	2	Fall	2024	\N
28	seng402	1	Spring	2025	\N
28	seng402	2	Spring	2025	\N
29	cs201	1	Fall	2024	\N
29	cs201	2	Fall	2024	\N
29	cs202	1	Spring	2025	\N
29	cs202	2	Spring	2025	\N
29	seng201	1	Fall	2024	\N
29	seng201	2	Fall	2024	\N
29	seng202	1	Spring	2025	\N
29	seng202	2	Spring	2025	\N
30	cs301	1	Fall	2024	\N
30	cs301	2	Fall	2024	\N
30	cs302	1	Spring	2025	\N
30	cs302	2	Spring	2025	\N
30	seng301	1	Fall	2024	\N
30	seng301	2	Fall	2024	\N
30	seng302	1	Spring	2025	\N
30	seng302	2	Spring	2025	\N
31	cs101	1	Fall	2024	\N
31	cs101	2	Fall	2024	\N
31	cs102	1	Spring	2025	\N
31	cs102	2	Spring	2025	\N
31	seng101	1	Fall	2024	\N
31	seng101	2	Fall	2024	\N
31	seng102	1	Spring	2025	\N
31	seng102	2	Spring	2025	\N
32	cs101	1	Fall	2024	\N
32	cs101	2	Fall	2024	\N
32	cs102	1	Spring	2025	\N
32	cs102	2	Spring	2025	\N
32	seng101	1	Fall	2024	\N
32	seng101	2	Fall	2024	\N
32	seng102	1	Spring	2025	\N
32	seng102	2	Spring	2025	\N
33	cs401	1	Fall	2024	\N
33	cs401	2	Fall	2024	\N
33	cs402	1	Spring	2025	\N
33	cs402	2	Spring	2025	\N
33	seng401	1	Fall	2024	\N
33	seng401	2	Fall	2024	\N
33	seng402	1	Spring	2025	\N
33	seng402	2	Spring	2025	\N
34	cs201	1	Fall	2024	\N
34	cs201	2	Fall	2024	\N
34	cs202	1	Spring	2025	\N
34	cs202	2	Spring	2025	\N
34	seng201	1	Fall	2024	\N
34	seng201	2	Fall	2024	\N
34	seng202	1	Spring	2025	\N
34	seng202	2	Spring	2025	\N
35	cs401	1	Fall	2024	\N
35	cs401	2	Fall	2024	\N
35	cs402	1	Spring	2025	\N
35	cs402	2	Spring	2025	\N
35	seng401	1	Fall	2024	\N
35	seng401	2	Fall	2024	\N
35	seng402	1	Spring	2025	\N
35	seng402	2	Spring	2025	\N
36	cs301	1	Fall	2024	\N
36	cs301	2	Fall	2024	\N
36	cs302	1	Spring	2025	\N
36	cs302	2	Spring	2025	\N
36	seng301	1	Fall	2024	\N
36	seng301	2	Fall	2024	\N
36	seng302	1	Spring	2025	\N
36	seng302	2	Spring	2025	\N
37	cs201	1	Fall	2024	\N
37	cs201	2	Fall	2024	\N
37	cs202	1	Spring	2025	\N
37	cs202	2	Spring	2025	\N
37	seng201	1	Fall	2024	\N
37	seng201	2	Fall	2024	\N
37	seng202	1	Spring	2025	\N
37	seng202	2	Spring	2025	\N
38	cs201	1	Fall	2024	\N
38	cs201	2	Fall	2024	\N
38	cs202	1	Spring	2025	\N
38	cs202	2	Spring	2025	\N
38	seng201	1	Fall	2024	\N
38	seng201	2	Fall	2024	\N
38	seng202	1	Spring	2025	\N
38	seng202	2	Spring	2025	\N
39	cs101	1	Fall	2024	\N
39	cs101	2	Fall	2024	\N
39	cs102	1	Spring	2025	\N
39	cs102	2	Spring	2025	\N
39	seng101	1	Fall	2024	\N
39	seng101	2	Fall	2024	\N
39	seng102	1	Spring	2025	\N
39	seng102	2	Spring	2025	\N
40	cs201	1	Fall	2024	\N
40	cs201	2	Fall	2024	\N
40	cs202	1	Spring	2025	\N
40	cs202	2	Spring	2025	\N
40	seng201	1	Fall	2024	\N
40	seng201	2	Fall	2024	\N
40	seng202	1	Spring	2025	\N
40	seng202	2	Spring	2025	\N
41	cs101	1	Fall	2024	\N
41	cs101	2	Fall	2024	\N
41	cs102	1	Spring	2025	\N
41	cs102	2	Spring	2025	\N
41	seng101	1	Fall	2024	\N
41	seng101	2	Fall	2024	\N
41	seng102	1	Spring	2025	\N
41	seng102	2	Spring	2025	\N
42	cs301	1	Fall	2024	\N
42	cs301	2	Fall	2024	\N
42	cs302	1	Spring	2025	\N
42	cs302	2	Spring	2025	\N
42	seng301	1	Fall	2024	\N
42	seng301	2	Fall	2024	\N
42	seng302	1	Spring	2025	\N
42	seng302	2	Spring	2025	\N
43	cs301	1	Fall	2024	\N
43	cs301	2	Fall	2024	\N
43	cs302	1	Spring	2025	\N
43	cs302	2	Spring	2025	\N
43	seng301	1	Fall	2024	\N
43	seng301	2	Fall	2024	\N
43	seng302	1	Spring	2025	\N
43	seng302	2	Spring	2025	\N
44	cs401	1	Fall	2024	\N
44	cs401	2	Fall	2024	\N
44	cs402	1	Spring	2025	\N
44	cs402	2	Spring	2025	\N
44	seng401	1	Fall	2024	\N
44	seng401	2	Fall	2024	\N
44	seng402	1	Spring	2025	\N
44	seng402	2	Spring	2025	\N
45	comp401	1	Fall	2024	\N
45	comp401	2	Fall	2024	\N
45	comp402	1	Spring	2025	\N
45	comp402	2	Spring	2025	\N
45	cs401	1	Fall	2024	\N
45	cs401	2	Fall	2024	\N
45	cs402	1	Spring	2025	\N
45	cs402	2	Spring	2025	\N
46	comp101	1	Fall	2024	\N
46	comp101	2	Fall	2024	\N
46	comp102	1	Spring	2025	\N
46	comp102	2	Spring	2025	\N
46	cs101	1	Fall	2024	\N
46	cs101	2	Fall	2024	\N
46	cs102	1	Spring	2025	\N
46	cs102	2	Spring	2025	\N
47	comp101	1	Fall	2024	\N
47	comp101	2	Fall	2024	\N
47	comp102	1	Spring	2025	\N
47	comp102	2	Spring	2025	\N
47	cs101	1	Fall	2024	\N
47	cs101	2	Fall	2024	\N
47	cs102	1	Spring	2025	\N
47	cs102	2	Spring	2025	\N
48	comp101	1	Fall	2024	\N
48	comp101	2	Fall	2024	\N
48	comp102	1	Spring	2025	\N
48	comp102	2	Spring	2025	\N
48	cs101	1	Fall	2024	\N
48	cs101	2	Fall	2024	\N
48	cs102	1	Spring	2025	\N
48	cs102	2	Spring	2025	\N
49	comp101	1	Fall	2024	\N
49	comp101	2	Fall	2024	\N
49	comp102	1	Spring	2025	\N
49	comp102	2	Spring	2025	\N
49	cs101	1	Fall	2024	\N
49	cs101	2	Fall	2024	\N
49	cs102	1	Spring	2025	\N
49	cs102	2	Spring	2025	\N
50	comp301	1	Fall	2024	\N
50	comp301	2	Fall	2024	\N
50	comp302	1	Spring	2025	\N
50	comp302	2	Spring	2025	\N
50	cs301	1	Fall	2024	\N
50	cs301	2	Fall	2024	\N
50	cs302	1	Spring	2025	\N
50	cs302	2	Spring	2025	\N
51	comp101	1	Fall	2024	\N
51	comp101	2	Fall	2024	\N
51	comp102	1	Spring	2025	\N
51	comp102	2	Spring	2025	\N
51	cs101	1	Fall	2024	\N
51	cs101	2	Fall	2024	\N
51	cs102	1	Spring	2025	\N
51	cs102	2	Spring	2025	\N
52	comp101	1	Fall	2024	\N
52	comp101	2	Fall	2024	\N
52	comp102	1	Spring	2025	\N
52	comp102	2	Spring	2025	\N
52	cs101	1	Fall	2024	\N
52	cs101	2	Fall	2024	\N
52	cs102	1	Spring	2025	\N
52	cs102	2	Spring	2025	\N
53	comp201	1	Fall	2024	\N
53	comp201	2	Fall	2024	\N
53	comp202	1	Spring	2025	\N
53	comp202	2	Spring	2025	\N
53	cs201	1	Fall	2024	\N
53	cs201	2	Fall	2024	\N
53	cs202	1	Spring	2025	\N
53	cs202	2	Spring	2025	\N
54	comp201	1	Fall	2024	\N
54	comp201	2	Fall	2024	\N
54	comp202	1	Spring	2025	\N
54	comp202	2	Spring	2025	\N
54	cs201	1	Fall	2024	\N
54	cs201	2	Fall	2024	\N
54	cs202	1	Spring	2025	\N
54	cs202	2	Spring	2025	\N
55	comp101	1	Fall	2024	\N
55	comp101	2	Fall	2024	\N
55	comp102	1	Spring	2025	\N
55	comp102	2	Spring	2025	\N
55	cs101	1	Fall	2024	\N
55	cs101	2	Fall	2024	\N
55	cs102	1	Spring	2025	\N
55	cs102	2	Spring	2025	\N
56	comp201	1	Fall	2024	\N
56	comp201	2	Fall	2024	\N
56	comp202	1	Spring	2025	\N
56	comp202	2	Spring	2025	\N
56	cs201	1	Fall	2024	\N
56	cs201	2	Fall	2024	\N
56	cs202	1	Spring	2025	\N
56	cs202	2	Spring	2025	\N
57	comp101	1	Fall	2024	\N
57	comp101	2	Fall	2024	\N
57	comp102	1	Spring	2025	\N
57	comp102	2	Spring	2025	\N
57	cs101	1	Fall	2024	\N
57	cs101	2	Fall	2024	\N
57	cs102	1	Spring	2025	\N
57	cs102	2	Spring	2025	\N
58	comp101	1	Fall	2024	\N
58	comp101	2	Fall	2024	\N
58	comp102	1	Spring	2025	\N
58	comp102	2	Spring	2025	\N
58	cs101	1	Fall	2024	\N
58	cs101	2	Fall	2024	\N
58	cs102	1	Spring	2025	\N
58	cs102	2	Spring	2025	\N
59	comp201	1	Fall	2024	\N
59	comp201	2	Fall	2024	\N
59	comp202	1	Spring	2025	\N
59	comp202	2	Spring	2025	\N
59	cs201	1	Fall	2024	\N
59	cs201	2	Fall	2024	\N
59	cs202	1	Spring	2025	\N
59	cs202	2	Spring	2025	\N
60	comp301	1	Fall	2024	\N
60	comp301	2	Fall	2024	\N
60	comp302	1	Spring	2025	\N
60	comp302	2	Spring	2025	\N
60	elec301	1	Fall	2024	\N
60	elec301	2	Fall	2024	\N
60	elec302	1	Spring	2025	\N
60	elec302	2	Spring	2025	\N
61	comp201	1	Fall	2024	\N
61	comp201	2	Fall	2024	\N
61	comp202	1	Spring	2025	\N
61	comp202	2	Spring	2025	\N
61	elec201	1	Fall	2024	\N
61	elec201	2	Fall	2024	\N
61	elec202	1	Spring	2025	\N
61	elec202	2	Spring	2025	\N
62	comp101	1	Fall	2024	\N
62	comp101	2	Fall	2024	\N
62	comp102	1	Spring	2025	\N
62	comp102	2	Spring	2025	\N
62	elec101	1	Fall	2024	\N
62	elec101	2	Fall	2024	\N
62	elec102	1	Spring	2025	\N
62	elec102	2	Spring	2025	\N
63	comp201	1	Fall	2024	\N
63	comp201	2	Fall	2024	\N
63	comp202	1	Spring	2025	\N
63	comp202	2	Spring	2025	\N
63	elec201	1	Fall	2024	\N
63	elec201	2	Fall	2024	\N
63	elec202	1	Spring	2025	\N
63	elec202	2	Spring	2025	\N
64	comp301	1	Fall	2024	\N
64	comp301	2	Fall	2024	\N
64	comp302	1	Spring	2025	\N
64	comp302	2	Spring	2025	\N
64	elec301	1	Fall	2024	\N
64	elec301	2	Fall	2024	\N
64	elec302	1	Spring	2025	\N
64	elec302	2	Spring	2025	\N
65	comp301	1	Fall	2024	\N
65	comp301	2	Fall	2024	\N
65	comp302	1	Spring	2025	\N
65	comp302	2	Spring	2025	\N
65	elec301	1	Fall	2024	\N
65	elec301	2	Fall	2024	\N
65	elec302	1	Spring	2025	\N
65	elec302	2	Spring	2025	\N
66	comp301	1	Fall	2024	\N
66	comp301	2	Fall	2024	\N
66	comp302	1	Spring	2025	\N
66	comp302	2	Spring	2025	\N
66	elec301	1	Fall	2024	\N
66	elec301	2	Fall	2024	\N
66	elec302	1	Spring	2025	\N
66	elec302	2	Spring	2025	\N
67	comp401	1	Fall	2024	\N
67	comp401	2	Fall	2024	\N
67	comp402	1	Spring	2025	\N
67	comp402	2	Spring	2025	\N
67	elec401	1	Fall	2024	\N
67	elec401	2	Fall	2024	\N
67	elec402	1	Spring	2025	\N
67	elec402	2	Spring	2025	\N
68	comp301	1	Fall	2024	\N
68	comp301	2	Fall	2024	\N
68	comp302	1	Spring	2025	\N
68	comp302	2	Spring	2025	\N
68	elec301	1	Fall	2024	\N
68	elec301	2	Fall	2024	\N
68	elec302	1	Spring	2025	\N
68	elec302	2	Spring	2025	\N
69	comp201	1	Fall	2024	\N
69	comp201	2	Fall	2024	\N
69	comp202	1	Spring	2025	\N
69	comp202	2	Spring	2025	\N
69	elec201	1	Fall	2024	\N
69	elec201	2	Fall	2024	\N
69	elec202	1	Spring	2025	\N
69	elec202	2	Spring	2025	\N
70	comp201	1	Fall	2024	\N
70	comp201	2	Fall	2024	\N
70	comp202	1	Spring	2025	\N
70	comp202	2	Spring	2025	\N
70	elec201	1	Fall	2024	\N
70	elec201	2	Fall	2024	\N
70	elec202	1	Spring	2025	\N
70	elec202	2	Spring	2025	\N
71	comp101	1	Fall	2024	\N
71	comp101	2	Fall	2024	\N
71	comp102	1	Spring	2025	\N
71	comp102	2	Spring	2025	\N
71	elec101	1	Fall	2024	\N
71	elec101	2	Fall	2024	\N
71	elec102	1	Spring	2025	\N
71	elec102	2	Spring	2025	\N
72	comp101	1	Fall	2024	\N
72	comp101	2	Fall	2024	\N
72	comp102	1	Spring	2025	\N
72	comp102	2	Spring	2025	\N
72	elec101	1	Fall	2024	\N
72	elec101	2	Fall	2024	\N
72	elec102	1	Spring	2025	\N
72	elec102	2	Spring	2025	\N
73	comp301	1	Fall	2024	\N
73	comp301	2	Fall	2024	\N
73	comp302	1	Spring	2025	\N
73	comp302	2	Spring	2025	\N
73	elec301	1	Fall	2024	\N
73	elec301	2	Fall	2024	\N
73	elec302	1	Spring	2025	\N
73	elec302	2	Spring	2025	\N
74	comp401	1	Fall	2024	\N
74	comp401	2	Fall	2024	\N
74	comp402	1	Spring	2025	\N
74	comp402	2	Spring	2025	\N
74	elec401	1	Fall	2024	\N
74	elec401	2	Fall	2024	\N
74	elec402	1	Spring	2025	\N
74	elec402	2	Spring	2025	\N
75	elec201	1	Fall	2024	\N
75	elec201	2	Fall	2024	\N
75	elec202	1	Spring	2025	\N
75	elec202	2	Spring	2025	\N
75	mech201	1	Fall	2024	\N
75	mech201	2	Fall	2024	\N
75	mech202	1	Spring	2025	\N
75	mech202	2	Spring	2025	\N
76	elec401	1	Fall	2024	\N
76	elec401	2	Fall	2024	\N
76	elec402	1	Spring	2025	\N
76	elec402	2	Spring	2025	\N
76	mech401	1	Fall	2024	\N
76	mech401	2	Fall	2024	\N
76	mech402	1	Spring	2025	\N
76	mech402	2	Spring	2025	\N
77	elec401	1	Fall	2024	\N
77	elec401	2	Fall	2024	\N
77	elec402	1	Spring	2025	\N
77	elec402	2	Spring	2025	\N
77	mech401	1	Fall	2024	\N
77	mech401	2	Fall	2024	\N
77	mech402	1	Spring	2025	\N
77	mech402	2	Spring	2025	\N
78	elec201	1	Fall	2024	\N
78	elec201	2	Fall	2024	\N
78	elec202	1	Spring	2025	\N
78	elec202	2	Spring	2025	\N
78	mech201	1	Fall	2024	\N
78	mech201	2	Fall	2024	\N
78	mech202	1	Spring	2025	\N
78	mech202	2	Spring	2025	\N
79	elec201	1	Fall	2024	\N
79	elec201	2	Fall	2024	\N
79	elec202	1	Spring	2025	\N
79	elec202	2	Spring	2025	\N
79	mech201	1	Fall	2024	\N
79	mech201	2	Fall	2024	\N
79	mech202	1	Spring	2025	\N
79	mech202	2	Spring	2025	\N
80	elec201	1	Fall	2024	\N
80	elec201	2	Fall	2024	\N
80	elec202	1	Spring	2025	\N
80	elec202	2	Spring	2025	\N
80	mech201	1	Fall	2024	\N
80	mech201	2	Fall	2024	\N
80	mech202	1	Spring	2025	\N
80	mech202	2	Spring	2025	\N
81	elec401	1	Fall	2024	\N
81	elec401	2	Fall	2024	\N
81	elec402	1	Spring	2025	\N
81	elec402	2	Spring	2025	\N
81	mech401	1	Fall	2024	\N
81	mech401	2	Fall	2024	\N
81	mech402	1	Spring	2025	\N
81	mech402	2	Spring	2025	\N
82	elec401	1	Fall	2024	\N
82	elec401	2	Fall	2024	\N
82	elec402	1	Spring	2025	\N
82	elec402	2	Spring	2025	\N
82	mech401	1	Fall	2024	\N
82	mech401	2	Fall	2024	\N
82	mech402	1	Spring	2025	\N
82	mech402	2	Spring	2025	\N
83	elec301	1	Fall	2024	\N
83	elec301	2	Fall	2024	\N
83	elec302	1	Spring	2025	\N
83	elec302	2	Spring	2025	\N
83	mech301	1	Fall	2024	\N
83	mech301	2	Fall	2024	\N
83	mech302	1	Spring	2025	\N
83	mech302	2	Spring	2025	\N
84	elec301	1	Fall	2024	\N
84	elec301	2	Fall	2024	\N
84	elec302	1	Spring	2025	\N
84	elec302	2	Spring	2025	\N
84	mech301	1	Fall	2024	\N
84	mech301	2	Fall	2024	\N
84	mech302	1	Spring	2025	\N
84	mech302	2	Spring	2025	\N
85	elec401	1	Fall	2024	\N
85	elec401	2	Fall	2024	\N
85	elec402	1	Spring	2025	\N
85	elec402	2	Spring	2025	\N
85	mech401	1	Fall	2024	\N
85	mech401	2	Fall	2024	\N
85	mech402	1	Spring	2025	\N
85	mech402	2	Spring	2025	\N
86	elec401	1	Fall	2024	\N
86	elec401	2	Fall	2024	\N
86	elec402	1	Spring	2025	\N
86	elec402	2	Spring	2025	\N
86	mech401	1	Fall	2024	\N
86	mech401	2	Fall	2024	\N
86	mech402	1	Spring	2025	\N
86	mech402	2	Spring	2025	\N
87	elec201	1	Fall	2024	\N
87	elec201	2	Fall	2024	\N
87	elec202	1	Spring	2025	\N
87	elec202	2	Spring	2025	\N
87	mech201	1	Fall	2024	\N
87	mech201	2	Fall	2024	\N
87	mech202	1	Spring	2025	\N
87	mech202	2	Spring	2025	\N
88	elec401	1	Fall	2024	\N
88	elec401	2	Fall	2024	\N
88	elec402	1	Spring	2025	\N
88	elec402	2	Spring	2025	\N
88	mech401	1	Fall	2024	\N
88	mech401	2	Fall	2024	\N
88	mech402	1	Spring	2025	\N
88	mech402	2	Spring	2025	\N
89	elec101	1	Fall	2024	\N
89	elec101	2	Fall	2024	\N
89	elec102	1	Spring	2025	\N
89	elec102	2	Spring	2025	\N
89	mech101	1	Fall	2024	\N
89	mech101	2	Fall	2024	\N
89	mech102	1	Spring	2025	\N
89	mech102	2	Spring	2025	\N
90	civ101	1	Fall	2024	\N
90	civ101	2	Fall	2024	\N
90	civ102	1	Spring	2025	\N
90	civ102	2	Spring	2025	\N
90	mech101	1	Fall	2024	\N
90	mech101	2	Fall	2024	\N
90	mech102	1	Spring	2025	\N
90	mech102	2	Spring	2025	\N
91	civ301	1	Fall	2024	\N
91	civ301	2	Fall	2024	\N
91	civ302	1	Spring	2025	\N
91	civ302	2	Spring	2025	\N
91	mech301	1	Fall	2024	\N
91	mech301	2	Fall	2024	\N
91	mech302	1	Spring	2025	\N
91	mech302	2	Spring	2025	\N
92	civ101	1	Fall	2024	\N
92	civ101	2	Fall	2024	\N
92	civ102	1	Spring	2025	\N
92	civ102	2	Spring	2025	\N
92	mech101	1	Fall	2024	\N
92	mech101	2	Fall	2024	\N
92	mech102	1	Spring	2025	\N
92	mech102	2	Spring	2025	\N
93	civ101	1	Fall	2024	\N
93	civ101	2	Fall	2024	\N
93	civ102	1	Spring	2025	\N
93	civ102	2	Spring	2025	\N
93	mech101	1	Fall	2024	\N
93	mech101	2	Fall	2024	\N
93	mech102	1	Spring	2025	\N
93	mech102	2	Spring	2025	\N
94	civ201	1	Fall	2024	\N
94	civ201	2	Fall	2024	\N
94	civ202	1	Spring	2025	\N
94	civ202	2	Spring	2025	\N
94	mech201	1	Fall	2024	\N
94	mech201	2	Fall	2024	\N
94	mech202	1	Spring	2025	\N
94	mech202	2	Spring	2025	\N
95	civ201	1	Fall	2024	\N
95	civ201	2	Fall	2024	\N
95	civ202	1	Spring	2025	\N
95	civ202	2	Spring	2025	\N
95	mech201	1	Fall	2024	\N
95	mech201	2	Fall	2024	\N
95	mech202	1	Spring	2025	\N
95	mech202	2	Spring	2025	\N
96	civ301	1	Fall	2024	\N
96	civ301	2	Fall	2024	\N
96	civ302	1	Spring	2025	\N
96	civ302	2	Spring	2025	\N
96	mech301	1	Fall	2024	\N
96	mech301	2	Fall	2024	\N
96	mech302	1	Spring	2025	\N
96	mech302	2	Spring	2025	\N
97	civ201	1	Fall	2024	\N
97	civ201	2	Fall	2024	\N
97	civ202	1	Spring	2025	\N
97	civ202	2	Spring	2025	\N
97	mech201	1	Fall	2024	\N
97	mech201	2	Fall	2024	\N
97	mech202	1	Spring	2025	\N
97	mech202	2	Spring	2025	\N
98	civ101	1	Fall	2024	\N
98	civ101	2	Fall	2024	\N
98	civ102	1	Spring	2025	\N
98	civ102	2	Spring	2025	\N
98	mech101	1	Fall	2024	\N
98	mech101	2	Fall	2024	\N
98	mech102	1	Spring	2025	\N
98	mech102	2	Spring	2025	\N
99	civ101	1	Fall	2024	\N
99	civ101	2	Fall	2024	\N
99	civ102	1	Spring	2025	\N
99	civ102	2	Spring	2025	\N
99	mech101	1	Fall	2024	\N
99	mech101	2	Fall	2024	\N
99	mech102	1	Spring	2025	\N
99	mech102	2	Spring	2025	\N
100	civ101	1	Fall	2024	\N
100	civ101	2	Fall	2024	\N
100	civ102	1	Spring	2025	\N
100	civ102	2	Spring	2025	\N
100	mech101	1	Fall	2024	\N
100	mech101	2	Fall	2024	\N
100	mech102	1	Spring	2025	\N
100	mech102	2	Spring	2025	\N
101	civ301	1	Fall	2024	\N
101	civ301	2	Fall	2024	\N
101	civ302	1	Spring	2025	\N
101	civ302	2	Spring	2025	\N
101	mech301	1	Fall	2024	\N
101	mech301	2	Fall	2024	\N
101	mech302	1	Spring	2025	\N
101	mech302	2	Spring	2025	\N
102	civ401	1	Fall	2024	\N
102	civ401	2	Fall	2024	\N
102	civ402	1	Spring	2025	\N
102	civ402	2	Spring	2025	\N
102	mech401	1	Fall	2024	\N
102	mech401	2	Fall	2024	\N
102	mech402	1	Spring	2025	\N
102	mech402	2	Spring	2025	\N
103	civ301	1	Fall	2024	\N
103	civ301	2	Fall	2024	\N
103	civ302	1	Spring	2025	\N
103	civ302	2	Spring	2025	\N
103	mech301	1	Fall	2024	\N
103	mech301	2	Fall	2024	\N
103	mech302	1	Spring	2025	\N
103	mech302	2	Spring	2025	\N
104	civ201	1	Fall	2024	\N
104	civ201	2	Fall	2024	\N
104	civ202	1	Spring	2025	\N
104	civ202	2	Spring	2025	\N
104	mech201	1	Fall	2024	\N
104	mech201	2	Fall	2024	\N
104	mech202	1	Spring	2025	\N
104	mech202	2	Spring	2025	\N
105	mech301	1	Fall	2024	\N
105	mech301	2	Fall	2024	\N
105	mech302	1	Spring	2025	\N
105	mech302	2	Spring	2025	\N
105	phy301	1	Fall	2024	\N
105	phy301	2	Fall	2024	\N
105	phy302	1	Spring	2025	\N
105	phy302	2	Spring	2025	\N
106	mech201	1	Fall	2024	\N
106	mech201	2	Fall	2024	\N
106	mech202	1	Spring	2025	\N
106	mech202	2	Spring	2025	\N
106	phy201	1	Fall	2024	\N
106	phy201	2	Fall	2024	\N
106	phy202	1	Spring	2025	\N
106	phy202	2	Spring	2025	\N
107	mech301	1	Fall	2024	\N
107	mech301	2	Fall	2024	\N
107	mech302	1	Spring	2025	\N
107	mech302	2	Spring	2025	\N
107	phy301	1	Fall	2024	\N
107	phy301	2	Fall	2024	\N
107	phy302	1	Spring	2025	\N
107	phy302	2	Spring	2025	\N
108	mech301	1	Fall	2024	\N
108	mech301	2	Fall	2024	\N
108	mech302	1	Spring	2025	\N
108	mech302	2	Spring	2025	\N
108	phy301	1	Fall	2024	\N
108	phy301	2	Fall	2024	\N
108	phy302	1	Spring	2025	\N
108	phy302	2	Spring	2025	\N
109	mech201	1	Fall	2024	\N
109	mech201	2	Fall	2024	\N
109	mech202	1	Spring	2025	\N
109	mech202	2	Spring	2025	\N
109	phy201	1	Fall	2024	\N
109	phy201	2	Fall	2024	\N
109	phy202	1	Spring	2025	\N
109	phy202	2	Spring	2025	\N
110	mech101	1	Fall	2024	\N
110	mech101	2	Fall	2024	\N
110	mech102	1	Spring	2025	\N
110	mech102	2	Spring	2025	\N
110	phy101	1	Fall	2024	\N
110	phy101	2	Fall	2024	\N
110	phy102	1	Spring	2025	\N
110	phy102	2	Spring	2025	\N
111	mech101	1	Fall	2024	\N
111	mech101	2	Fall	2024	\N
111	mech102	1	Spring	2025	\N
111	mech102	2	Spring	2025	\N
111	phy101	1	Fall	2024	\N
111	phy101	2	Fall	2024	\N
111	phy102	1	Spring	2025	\N
111	phy102	2	Spring	2025	\N
112	mech101	1	Fall	2024	\N
112	mech101	2	Fall	2024	\N
112	mech102	1	Spring	2025	\N
112	mech102	2	Spring	2025	\N
112	phy101	1	Fall	2024	\N
112	phy101	2	Fall	2024	\N
112	phy102	1	Spring	2025	\N
112	phy102	2	Spring	2025	\N
113	mech301	1	Fall	2024	\N
113	mech301	2	Fall	2024	\N
113	mech302	1	Spring	2025	\N
113	mech302	2	Spring	2025	\N
113	phy301	1	Fall	2024	\N
113	phy301	2	Fall	2024	\N
113	phy302	1	Spring	2025	\N
113	phy302	2	Spring	2025	\N
114	mech101	1	Fall	2024	\N
114	mech101	2	Fall	2024	\N
114	mech102	1	Spring	2025	\N
114	mech102	2	Spring	2025	\N
114	phy101	1	Fall	2024	\N
114	phy101	2	Fall	2024	\N
114	phy102	1	Spring	2025	\N
114	phy102	2	Spring	2025	\N
115	chem201	1	Fall	2024	\N
115	chem201	2	Fall	2024	\N
115	chem202	1	Spring	2025	\N
115	chem202	2	Spring	2025	\N
115	phy201	1	Fall	2024	\N
115	phy201	2	Fall	2024	\N
115	phy202	1	Spring	2025	\N
115	phy202	2	Spring	2025	\N
116	chem301	1	Fall	2024	\N
116	chem301	2	Fall	2024	\N
116	chem302	1	Spring	2025	\N
116	chem302	2	Spring	2025	\N
116	phy301	1	Fall	2024	\N
116	phy301	2	Fall	2024	\N
116	phy302	1	Spring	2025	\N
116	phy302	2	Spring	2025	\N
117	chem101	1	Fall	2024	\N
117	chem101	2	Fall	2024	\N
117	chem102	1	Spring	2025	\N
117	chem102	2	Spring	2025	\N
117	phy101	1	Fall	2024	\N
117	phy101	2	Fall	2024	\N
117	phy102	1	Spring	2025	\N
117	phy102	2	Spring	2025	\N
118	chem301	1	Fall	2024	\N
118	chem301	2	Fall	2024	\N
118	chem302	1	Spring	2025	\N
118	chem302	2	Spring	2025	\N
118	phy301	1	Fall	2024	\N
118	phy301	2	Fall	2024	\N
118	phy302	1	Spring	2025	\N
118	phy302	2	Spring	2025	\N
119	chem101	1	Fall	2024	\N
119	chem101	2	Fall	2024	\N
119	chem102	1	Spring	2025	\N
119	chem102	2	Spring	2025	\N
119	phy101	1	Fall	2024	\N
119	phy101	2	Fall	2024	\N
119	phy102	1	Spring	2025	\N
119	phy102	2	Spring	2025	\N
120	chem101	1	Fall	2024	\N
120	chem101	2	Fall	2024	\N
120	chem102	1	Spring	2025	\N
120	chem102	2	Spring	2025	\N
120	phy101	1	Fall	2024	\N
120	phy101	2	Fall	2024	\N
120	phy102	1	Spring	2025	\N
120	phy102	2	Spring	2025	\N
121	chem401	1	Fall	2024	\N
121	chem401	2	Fall	2024	\N
121	chem402	1	Spring	2025	\N
121	chem402	2	Spring	2025	\N
121	phy401	1	Fall	2024	\N
121	phy401	2	Fall	2024	\N
121	phy402	1	Spring	2025	\N
121	phy402	2	Spring	2025	\N
122	chem401	1	Fall	2024	\N
122	chem401	2	Fall	2024	\N
122	chem402	1	Spring	2025	\N
122	chem402	2	Spring	2025	\N
122	phy401	1	Fall	2024	\N
122	phy401	2	Fall	2024	\N
122	phy402	1	Spring	2025	\N
122	phy402	2	Spring	2025	\N
123	chem301	1	Fall	2024	\N
123	chem301	2	Fall	2024	\N
123	chem302	1	Spring	2025	\N
123	chem302	2	Spring	2025	\N
123	phy301	1	Fall	2024	\N
123	phy301	2	Fall	2024	\N
123	phy302	1	Spring	2025	\N
123	phy302	2	Spring	2025	\N
124	chem301	1	Fall	2024	\N
124	chem301	2	Fall	2024	\N
124	chem302	1	Spring	2025	\N
124	chem302	2	Spring	2025	\N
124	phy301	1	Fall	2024	\N
124	phy301	2	Fall	2024	\N
124	phy302	1	Spring	2025	\N
124	phy302	2	Spring	2025	\N
125	bio301	1	Fall	2024	\N
125	bio301	2	Fall	2024	\N
125	bio302	1	Spring	2025	\N
125	bio302	2	Spring	2025	\N
125	chem301	1	Fall	2024	\N
125	chem301	2	Fall	2024	\N
125	chem302	1	Spring	2025	\N
125	chem302	2	Spring	2025	\N
126	bio101	1	Fall	2024	\N
126	bio101	2	Fall	2024	\N
126	bio102	1	Spring	2025	\N
126	bio102	2	Spring	2025	\N
126	chem101	1	Fall	2024	\N
126	chem101	2	Fall	2024	\N
126	chem102	1	Spring	2025	\N
126	chem102	2	Spring	2025	\N
127	bio301	1	Fall	2024	\N
127	bio301	2	Fall	2024	\N
127	bio302	1	Spring	2025	\N
127	bio302	2	Spring	2025	\N
127	chem301	1	Fall	2024	\N
127	chem301	2	Fall	2024	\N
127	chem302	1	Spring	2025	\N
127	chem302	2	Spring	2025	\N
128	bio301	1	Fall	2024	\N
128	bio301	2	Fall	2024	\N
128	bio302	1	Spring	2025	\N
128	bio302	2	Spring	2025	\N
128	chem301	1	Fall	2024	\N
128	chem301	2	Fall	2024	\N
128	chem302	1	Spring	2025	\N
128	chem302	2	Spring	2025	\N
129	bio201	1	Fall	2024	\N
129	bio201	2	Fall	2024	\N
129	bio202	1	Spring	2025	\N
129	bio202	2	Spring	2025	\N
129	chem201	1	Fall	2024	\N
129	chem201	2	Fall	2024	\N
129	chem202	1	Spring	2025	\N
129	chem202	2	Spring	2025	\N
130	bio101	1	Fall	2024	\N
130	bio101	2	Fall	2024	\N
130	bio102	1	Spring	2025	\N
130	bio102	2	Spring	2025	\N
130	chem101	1	Fall	2024	\N
130	chem101	2	Fall	2024	\N
130	chem102	1	Spring	2025	\N
130	chem102	2	Spring	2025	\N
131	bio101	1	Fall	2024	\N
131	bio101	2	Fall	2024	\N
131	bio102	1	Spring	2025	\N
131	bio102	2	Spring	2025	\N
131	chem101	1	Fall	2024	\N
131	chem101	2	Fall	2024	\N
131	chem102	1	Spring	2025	\N
131	chem102	2	Spring	2025	\N
132	bio201	1	Fall	2024	\N
132	bio201	2	Fall	2024	\N
132	bio202	1	Spring	2025	\N
132	bio202	2	Spring	2025	\N
132	chem201	1	Fall	2024	\N
132	chem201	2	Fall	2024	\N
132	chem202	1	Spring	2025	\N
132	chem202	2	Spring	2025	\N
133	bio301	1	Fall	2024	\N
133	bio301	2	Fall	2024	\N
133	bio302	1	Spring	2025	\N
133	bio302	2	Spring	2025	\N
133	chem301	1	Fall	2024	\N
133	chem301	2	Fall	2024	\N
133	chem302	1	Spring	2025	\N
133	chem302	2	Spring	2025	\N
134	bio301	1	Fall	2024	\N
134	bio301	2	Fall	2024	\N
134	bio302	1	Spring	2025	\N
134	bio302	2	Spring	2025	\N
134	chem301	1	Fall	2024	\N
134	chem301	2	Fall	2024	\N
134	chem302	1	Spring	2025	\N
134	chem302	2	Spring	2025	\N
\.


--
-- Data for Name: teaches; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.teaches (id, course_id, sec_id, semester, year) FROM stdin;
1	comp101	2	Fall	2024
1	comp102	1	Spring	2025
1	comp102	2	Spring	2025
1	comp202	2	Spring	2025
1	comp301	2	Fall	2024
1	comp402	2	Spring	2025
2	comp101	1	Fall	2024
2	comp201	1	Fall	2024
2	comp301	1	Fall	2024
2	comp302	2	Spring	2025
2	comp401	1	Fall	2024
2	comp401	2	Fall	2024
3	comp201	2	Fall	2024
3	comp202	1	Spring	2025
3	comp302	1	Spring	2025
3	comp402	1	Spring	2025
4	seng101	1	Fall	2024
4	seng102	1	Spring	2025
4	seng102	2	Spring	2025
4	seng202	2	Spring	2025
4	seng302	1	Spring	2025
4	seng402	1	Spring	2025
5	seng201	1	Fall	2024
5	seng201	2	Fall	2024
5	seng301	1	Fall	2024
5	seng302	2	Spring	2025
5	seng401	1	Fall	2024
5	seng402	2	Spring	2025
6	seng101	2	Fall	2024
6	seng202	1	Spring	2025
6	seng301	2	Fall	2024
6	seng401	2	Fall	2024
7	cs101	2	Fall	2024
7	cs102	2	Spring	2025
7	cs202	1	Spring	2025
7	cs402	1	Spring	2025
8	cs101	1	Fall	2024
8	cs102	1	Spring	2025
8	cs201	1	Fall	2024
8	cs201	2	Fall	2024
8	cs202	2	Spring	2025
8	cs402	2	Spring	2025
9	cs301	1	Fall	2024
9	cs301	2	Fall	2024
9	cs302	1	Spring	2025
9	cs302	2	Spring	2025
9	cs401	1	Fall	2024
9	cs401	2	Fall	2024
10	elec102	2	Spring	2025
10	elec202	1	Spring	2025
10	elec202	2	Spring	2025
10	elec301	2	Fall	2024
10	elec401	1	Fall	2024
10	elec402	1	Spring	2025
10	elec402	2	Spring	2025
11	elec101	1	Fall	2024
11	elec201	2	Fall	2024
11	elec302	1	Spring	2025
11	elec302	2	Spring	2025
12	elec101	2	Fall	2024
12	elec102	1	Spring	2025
12	elec201	1	Fall	2024
12	elec301	1	Fall	2024
12	elec401	2	Fall	2024
13	mech101	1	Fall	2024
13	mech102	2	Spring	2025
13	mech201	1	Fall	2024
13	mech301	1	Fall	2024
13	mech302	1	Spring	2025
13	mech302	2	Spring	2025
13	mech401	1	Fall	2024
14	mech101	2	Fall	2024
14	mech102	1	Spring	2025
14	mech201	2	Fall	2024
14	mech402	1	Spring	2025
15	mech202	1	Spring	2025
15	mech202	2	Spring	2025
15	mech301	2	Fall	2024
15	mech401	2	Fall	2024
15	mech402	2	Spring	2025
16	civ101	2	Fall	2024
16	civ202	1	Spring	2025
16	civ401	1	Fall	2024
16	civ401	2	Fall	2024
17	civ101	1	Fall	2024
17	civ201	1	Fall	2024
17	civ202	2	Spring	2025
17	civ301	2	Fall	2024
17	civ302	1	Spring	2025
17	civ302	2	Spring	2025
17	civ402	1	Spring	2025
17	civ402	2	Spring	2025
18	civ102	1	Spring	2025
18	civ102	2	Spring	2025
18	civ201	2	Fall	2024
18	civ301	1	Fall	2024
19	phy101	2	Fall	2024
19	phy202	2	Spring	2025
19	phy301	2	Fall	2024
19	phy401	2	Fall	2024
19	phy402	2	Spring	2025
20	phy101	1	Fall	2024
20	phy102	2	Spring	2025
20	phy201	1	Fall	2024
20	phy201	2	Fall	2024
20	phy302	2	Spring	2025
20	phy401	1	Fall	2024
20	phy402	1	Spring	2025
21	phy102	1	Spring	2025
21	phy202	1	Spring	2025
21	phy301	1	Fall	2024
21	phy302	1	Spring	2025
22	chem101	1	Fall	2024
22	chem102	1	Spring	2025
22	chem201	1	Fall	2024
22	chem202	2	Spring	2025
23	chem201	2	Fall	2024
23	chem301	1	Fall	2024
23	chem301	2	Fall	2024
23	chem401	2	Fall	2024
23	chem402	2	Spring	2025
24	chem101	2	Fall	2024
24	chem102	2	Spring	2025
24	chem202	1	Spring	2025
24	chem302	1	Spring	2025
24	chem302	2	Spring	2025
24	chem401	1	Fall	2024
24	chem402	1	Spring	2025
25	bio101	1	Fall	2024
25	bio101	2	Fall	2024
25	bio102	2	Spring	2025
25	bio201	1	Fall	2024
25	bio402	1	Spring	2025
26	bio202	1	Spring	2025
26	bio301	2	Fall	2024
26	bio302	1	Spring	2025
26	bio302	2	Spring	2025
26	bio401	1	Fall	2024
26	bio401	2	Fall	2024
26	bio402	2	Spring	2025
27	bio102	1	Spring	2025
27	bio201	2	Fall	2024
27	bio202	2	Spring	2025
27	bio301	1	Fall	2024
\.


--
-- Data for Name: time_slot; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.time_slot (time_slot_id, day, start_time, end_time) FROM stdin;
1	Monday	08:00:00	10:00:00
2	Monday	10:30:00	12:30:00
3	Monday	13:00:00	15:00:00
4	Monday	15:30:00	18:30:00
5	Tuesday	08:00:00	10:00:00
6	Tuesday	10:30:00	12:30:00
7	Tuesday	13:00:00	15:00:00
8	Tuesday	15:30:00	17:30:00
9	Wednesday	08:00:00	10:00:00
10	Wednesday	10:30:00	13:30:00
11	Wednesday	14:00:00	16:00:00
12	Wednesday	16:30:00	18:30:00
13	Thursday	08:00:00	10:00:00
14	Thursday	10:30:00	12:30:00
15	Thursday	13:00:00	15:00:00
16	Thursday	15:30:00	17:30:00
17	Friday	08:00:00	10:00:00
18	Friday	10:30:00	13:30:00
19	Friday	14:00:00	16:00:00
20	Friday	16:30:00	18:30:00
\.


--
-- Name: instructor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.instructor_id_seq', 27, true);


--
-- Name: student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.student_id_seq', 134, true);


--
-- Name: takes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.takes_id_seq', 1, false);


--
-- Name: teaches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.teaches_id_seq', 1, false);


--
-- Name: time_slot_time_slot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.time_slot_time_slot_id_seq', 20, true);


--
-- Name: advisor advisor_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.advisor
    ADD CONSTRAINT advisor_pkey PRIMARY KEY (s_id);


--
-- Name: classroom classroom_candidate_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.classroom
    ADD CONSTRAINT classroom_candidate_key UNIQUE (building, room_number);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (course_id);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (dept_name);


--
-- Name: instructor instructor_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.instructor
    ADD CONSTRAINT instructor_pkey PRIMARY KEY (id);


--
-- Name: prereq prereq_candidate_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.prereq
    ADD CONSTRAINT prereq_candidate_key UNIQUE (course_id, prereq_id);


--
-- Name: section section_candidate_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_candidate_key UNIQUE (course_id, sec_id, semester, year);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (id);


--
-- Name: takes takes_candidate_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.takes
    ADD CONSTRAINT takes_candidate_key UNIQUE (id, course_id, sec_id, semester, year);


--
-- Name: teaches teaches_candidate_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.teaches
    ADD CONSTRAINT teaches_candidate_key UNIQUE (id, course_id, sec_id, semester, year);


--
-- Name: time_slot time_slot_candidate_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.time_slot
    ADD CONSTRAINT time_slot_candidate_key UNIQUE (time_slot_id, day, start_time);


--
-- Name: time_slot time_slot_time_slot_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.time_slot
    ADD CONSTRAINT time_slot_time_slot_id_key UNIQUE (time_slot_id);


--
-- Name: advisor advisor_i_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.advisor
    ADD CONSTRAINT advisor_i_id_fkey FOREIGN KEY (i_id) REFERENCES public.instructor(id);


--
-- Name: advisor advisor_s_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.advisor
    ADD CONSTRAINT advisor_s_id_fkey FOREIGN KEY (s_id) REFERENCES public.student(id);


--
-- Name: course course_dept_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_dept_name_fkey FOREIGN KEY (dept_name) REFERENCES public.department(dept_name);


--
-- Name: instructor instructor_dept_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.instructor
    ADD CONSTRAINT instructor_dept_name_fkey FOREIGN KEY (dept_name) REFERENCES public.department(dept_name);


--
-- Name: prereq prereq_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.prereq
    ADD CONSTRAINT prereq_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id);


--
-- Name: prereq prereq_prereq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.prereq
    ADD CONSTRAINT prereq_prereq_id_fkey FOREIGN KEY (prereq_id) REFERENCES public.course(course_id);


--
-- Name: section section_building_room_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_building_room_number_fkey FOREIGN KEY (building, room_number) REFERENCES public.classroom(building, room_number);


--
-- Name: section section_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id);


--
-- Name: section section_time_slot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_time_slot_id_fkey FOREIGN KEY (time_slot_id) REFERENCES public.time_slot(time_slot_id);


--
-- Name: student student_dept_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_dept_name_fkey FOREIGN KEY (dept_name) REFERENCES public.department(dept_name);


--
-- Name: takes takes_course_id_sec_id_semester_year_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.takes
    ADD CONSTRAINT takes_course_id_sec_id_semester_year_fkey FOREIGN KEY (course_id, sec_id, semester, year) REFERENCES public.section(course_id, sec_id, semester, year);


--
-- Name: takes takes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.takes
    ADD CONSTRAINT takes_id_fkey FOREIGN KEY (id) REFERENCES public.student(id);


--
-- Name: teaches teaches_course_id_sec_id_semester_year_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.teaches
    ADD CONSTRAINT teaches_course_id_sec_id_semester_year_fkey FOREIGN KEY (course_id, sec_id, semester, year) REFERENCES public.section(course_id, sec_id, semester, year);


--
-- Name: teaches teaches_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.teaches
    ADD CONSTRAINT teaches_id_fkey FOREIGN KEY (id) REFERENCES public.instructor(id);


--
-- PostgreSQL database dump complete
--

